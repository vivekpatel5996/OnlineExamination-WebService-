﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceModel;
using WCFValidate; 
namespace WCFHost
{
    
    public partial class Form1 : Form
    {
        ServiceHost sh = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sh = new ServiceHost(typeof(WCFValidate.ServiceClass));
            sh.Open();
            label1.Text = "Service is also Runnig.Only You are dumb! Huuh !";
        }

        private void Form1_Closing(object sender,EventArgs e)
        {
            sh.Close();
        }


    }
}
