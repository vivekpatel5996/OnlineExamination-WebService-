﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WCFValidate
{
  public class ServiceClass:IService
    {
        Boolean IService.Validate(String username,string password)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            
            //IQueryable<string> unames= db.Tables.;
            
            var  pwds = db.Tables.Select(p => new { p.password,p.username}).ToList();

            //   un = "vivek";
            // pwd = "patel";
            foreach (var u in pwds)
            {
                if (u.username ==username && u.password==password)
                    return true;
             }
            return false; 
        }
    }
}
