﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace WCFValidate
{
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        Boolean Validate(string username,string password);
    }
}
